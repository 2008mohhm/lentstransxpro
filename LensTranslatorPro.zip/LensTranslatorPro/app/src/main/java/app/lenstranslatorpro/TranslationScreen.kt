package app.lenstranslatorpro

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun TranslationScreen(vm: TranslationViewModel = viewModel()) {
    val ctx = LocalContext.current
    val s by vm.settings.collectAsState()
    val clipboard = LocalClipboardManager.current
    val speaker = remember { Speaker(ctx) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }

    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()
    val srcLang = if (s.source == "auto") vm.detected.ifBlank { "en" } else s.source

    fun doTranslate() {
        vm.translate { r -> if (s.autoSpeak) speaker.speak(r, s.target, s.speechRate, s.pitch) }
    }

    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!t.isNullOrBlank()) {
            vm.input = t
            doTranslate()
        }
    }

    fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        if (s.source != "auto") i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, s.source)
        try { voiceLauncher.launch(i) } catch (e: Exception) { toast("التعرف على الصوت غير متاح على هذا الجهاز") }
    }

    fun startBubble() {
        if (!Settings.canDrawOverlays(ctx)) {
            toast("فعّل إذن العرض فوق التطبيقات ثم ارجع واضغط من جديد")
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
        } else {
            ContextCompat.startForegroundService(ctx, Intent(ctx, FloatingTranslateService::class.java))
        }
    }

    fun remind(min: Int) {
        ReminderHelper.schedule(ctx, min, vm.output.ifBlank { vm.input }.ifBlank { "تذكير" })
        toast("سيصلك تنبيه بعد $min دقيقة")
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("LensTranslatorPro", style = MaterialTheme.typography.headlineMedium)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            LanguagePicker("من", s.source, true, Modifier.weight(1f)) { c -> vm.update { it.copy(source = c) } }
            OutlinedButton(onClick = {
                if (s.source != "auto") vm.update { it.copy(source = it.target, target = it.source) }
            }) { Text("⇄") }
            LanguagePicker("إلى", s.target, false, Modifier.weight(1f)) { c -> vm.update { it.copy(target = c) } }
        }

        OutlinedTextField(
            value = vm.input,
            onValueChange = { vm.input = it },
            label = { Text("النص") },
            modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp)
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { doTranslate() },
                enabled = !vm.loading && vm.input.isNotBlank(),
                modifier = Modifier.weight(1f)
            ) { Text(if (vm.loading) "جارٍ..." else "ترجمة") }
            OutlinedButton(onClick = { startVoice() }) { Text("🎤") }
            OutlinedButton(onClick = {
                val t = clipboard.getText()?.text.orEmpty()
                if (t.isNotBlank()) {
                    vm.input = t
                    if (s.autoTranslateOnPaste) doTranslate()
                }
            }) { Text("لصق") }
            OutlinedButton(onClick = { vm.input = ""; vm.output = ""; vm.extra = ""; vm.error = "" }) { Text("مسح") }
        }

        if (vm.error.isNotBlank()) Text(vm.error, color = MaterialTheme.colorScheme.error)

        if (vm.output.isNotBlank()) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("الترجمة", style = MaterialTheme.typography.labelLarge)
                    Text(vm.output, style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { clipboard.setText(AnnotatedString(vm.input)); toast("تم نسخ الأصلي") }, modifier = Modifier.weight(1f)) { Text("نسخ الأصلي") }
                        OutlinedButton(onClick = { clipboard.setText(AnnotatedString(vm.output)); toast("تم نسخ الترجمة") }, modifier = Modifier.weight(1f)) { Text("نسخ الترجمة") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { speaker.speak(vm.input, srcLang, s.speechRate, s.pitch) }, modifier = Modifier.weight(1f)) { Text("استمع للأصلي") }
                        OutlinedButton(onClick = { speaker.speak(vm.output, s.target, s.speechRate, s.pitch) }, modifier = Modifier.weight(1f)) { Text("استمع للترجمة") }
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("أدوات ذكية (محلية)", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.explain() }, enabled = vm.output.isNotBlank(), modifier = Modifier.weight(1f)) { Text("شرح") }
                    OutlinedButton(onClick = { vm.summarize() }, enabled = vm.input.isNotBlank(), modifier = Modifier.weight(1f)) { Text("تلخيص") }
                }
                if (vm.extra.isNotBlank()) Text(vm.extra)
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("تذكير", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(5, 30, 60).forEach { m ->
                        OutlinedButton(onClick = { remind(m) }, modifier = Modifier.weight(1f)) { Text("$m د") }
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الفقاعة العائمة", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { startBubble() }, modifier = Modifier.weight(1f)) { Text("تشغيل") }
                    OutlinedButton(
                        onClick = { ctx.stopService(Intent(ctx, FloatingTranslateService::class.java)) },
                        modifier = Modifier.weight(1f)
                    ) { Text("إيقاف") }
                }
                SliderRow("الشفافية", s.overlayOpacity, 0.3f, 1f) { v -> vm.update { it.copy(overlayOpacity = v) } }
                SliderRow("الحجم", s.overlaySize.toFloat(), 40f, 96f) { v -> vm.update { it.copy(overlaySize = v.toInt()) } }
                Text("التغييرات تُطبّق عند إعادة تشغيل الفقاعة", style = MaterialTheme.typography.bodySmall)
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الإعدادات", style = MaterialTheme.typography.labelLarge)
                SwitchRow("ترجمة تلقائية عند اللصق", s.autoTranslateOnPaste) { v -> vm.update { it.copy(autoTranslateOnPaste = v) } }
                SwitchRow("نطق الترجمة تلقائيًا", s.autoSpeak) { v -> vm.update { it.copy(autoSpeak = v) } }
                SwitchRow("الوضع الداكن", s.darkMode) { v -> vm.update { it.copy(darkMode = v) } }
                SliderRow("سرعة الصوت", s.speechRate, 0.5f, 2f) { v -> vm.update { it.copy(speechRate = v) } }
                SliderRow("درجة الصوت", s.pitch, 0.5f, 2f) { v -> vm.update { it.copy(pitch = v) } }
            }
        }
    }
}

@Composable
private fun LanguagePicker(label: String, value: String, includeAuto: Boolean, modifier: Modifier, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val options = (if (includeAuto) listOf(Lang("auto", "تلقائي")) else emptyList()) + Languages.all
    Box(modifier) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: ${Languages.name(value)}", maxLines = 1)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { l ->
                DropdownMenuItem(text = { Text(l.name) }, onClick = { onSelect(l.code); open = false })
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SliderRow(label: String, value: Float, min: Float, max: Float, onFinished: (Float) -> Unit) {
    var local by remember(value) { mutableStateOf(value) }
    Column {
        Text("$label: ${"%.1f".format(local)}")
        Slider(value = local, onValueChange = { local = it }, onValueChangeFinished = { onFinished(local) }, valueRange = min..max)
    }
}
